const mongoose = require('mongoose');

const getConnection = async () =>{
    try {
        const url='mongodb://usuario-bd:umhcuiWki6MJneKf@ac-5vbld9z-shard-00-00.c7qqxsq.mongodb.net:27017,ac-5vbld9z-shard-00-01.c7qqxsq.mongodb.net:27017,ac-5vbld9z-shard-00-02.c7qqxsq.mongodb.net:27017/inventarios-iud?ssl=true&replicaSet=atlas-hut51z-shard-0&authSource=admin&retryWrites=true&w=majority'
        await mongoose.connect(url);
    
        console.log('Conexion exitosa');

    }catch(error){
        console.log(error);
    }
}
module.exports={
    getConnection,
}